package com.capgemini.core.busbooking.dto;

import java.io.Serializable;

//JavaBean
public class BusSchedule implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3522632542517613975L;
	
	private int busId;
	private String name;
	private String startLocation;
	private String endLocation;
	private String timing;
	private int noOfAvailableSeats;
	
	public BusSchedule() {
	}

	public BusSchedule(int busId, String name, String startLocation, String endLocation, String timing,
			int noOfAvailableSeats) {
		super();
		this.busId = busId;
		this.name = name;
		this.startLocation = startLocation;
		this.endLocation = endLocation;
		this.timing = timing;
		this.noOfAvailableSeats = noOfAvailableSeats;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStartLocation() {
		return startLocation;
	}

	public void setStartLocation(String startLocation) {
		this.startLocation = startLocation;
	}

	public String getEndLocation() {
		return endLocation;
	}

	public void setEndLocation(String endLocation) {
		this.endLocation = endLocation;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public int getNoOfAvailableSeats() {
		return noOfAvailableSeats;
	}

	public void setNoOfAvailableSeats(int noOfAvailableSeats) {
		this.noOfAvailableSeats = noOfAvailableSeats;
	}

	@Override
	public String toString() {
		return "BusSchedule [busId=" + busId + ", name=" + name + ", startLocation=" + startLocation + ", endLocation="
				+ endLocation + ", timing=" + timing + ", noOfAvailableSeats=" + noOfAvailableSeats + "]";
	}
	
	

}
