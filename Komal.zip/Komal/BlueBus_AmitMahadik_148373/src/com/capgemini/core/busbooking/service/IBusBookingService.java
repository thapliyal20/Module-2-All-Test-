package com.capgemini.core.busbooking.service;

import java.util.List;

import com.capgemini.core.busbooking.dto.BookingDetails;
import com.capgemini.core.busbooking.dto.BusSchedule;
import com.capgemini.core.busbooking.exception.BusBookingException;

public interface IBusBookingService {

	public List<BusSchedule> getBusSchedule() throws BusBookingException;
	
	public int bookABus( BookingDetails bookingDetails )throws BusBookingException;
	
}
