package com.cg.frs.dto;

public class FLatRegistrationDTO {
	// declaring variables
	private int flatRegNo;
	private int ownerIdNo;
	private int flatType;
	private int flatArea;
	private int RentAmount;
	private int DepositAmount;

	// getters and setters for all the static variables created
	public int getFlatRegNo() {
		return flatRegNo;
	}

	public void setFlatRegNo(int flatRegNo) {
		this.flatRegNo = flatRegNo;
	}

	public int getOwnerIdNo() {
		return ownerIdNo;
	}

	public void setOwnerIdNo(int ownerIdNo) {
		if (this.ownerIdNo != 1 || this.ownerIdNo != 2 || this.ownerIdNo != 3)
			System.out.println("Owner does not exist");
		else
			this.ownerIdNo = ownerIdNo;
	}

	public int getFlatType() {
		return flatType;
	}

	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}

	public int getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}

	public int getRentAmount() {
		return RentAmount;
	}

	public void setRentAmount(int rentAmount) {
		RentAmount = rentAmount;
	}

	public int getDepositAmount() {
		return DepositAmount;
	}

	public void setDepositAmount(int depositAmount) {
		if (DepositAmount < RentAmount)
			System.out
					.println("Deposit Amount cannot be less than Rent Amount");
		else
			DepositAmount = depositAmount;
	}

	// parameterized constructor has been created
	public FLatRegistrationDTO(int flatRegNo, int ownerIdNo, int flatType,
			int flatArea, int rentAmount, int depositAmount) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerIdNo = ownerIdNo;
		this.flatType = flatType;
		this.flatArea = flatArea;
		RentAmount = rentAmount;
		DepositAmount = depositAmount;
	}

	// another parameterized constructor has been created for the inputs being
	// taken
	public FLatRegistrationDTO(int ownerIdNo, int flatType, int flatArea,
			int rentAmount, int depositAmount) {
		super();
		this.ownerIdNo = ownerIdNo;
		this.flatType = flatType;
		this.flatArea = flatArea;
		RentAmount = rentAmount;
		DepositAmount = depositAmount;
	}

	// default constructor
	public FLatRegistrationDTO() {

	}

	// toString method
	@Override
	public String toString() {
		return "FLatRegistrationDTO [flatRegNo=" + flatRegNo + ", ownerIdNo="
				+ ownerIdNo + ", flatType=" + flatType + ", flatArea="
				+ flatArea + ", RentAmount=" + RentAmount + ", DepositAmount="
				+ DepositAmount + "]";
	}

}
