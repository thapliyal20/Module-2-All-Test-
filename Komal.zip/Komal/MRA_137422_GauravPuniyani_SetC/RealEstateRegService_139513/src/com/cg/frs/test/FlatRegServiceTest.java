package com.cg.frs.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;
import com.cg.frs.service.FlatRegistrationServiceImpl;

public class FlatRegServiceTest {
	static FlatRegistrationServiceImpl dao;// static declaration of service
											// class
	static FLatRegistrationDTO bean;// static declaration of DTO class

	// this is to create the beforeclass annotation
	@BeforeClass
	public static void initializes() {
		System.out.println("In before class");
		dao = new FlatRegistrationServiceImpl();
		bean = new FLatRegistrationDTO(1, 1, 650, 7000, 25000);// values are
																// being passed
	}

	// before annotation has been created
	@Before
	public void ini() {
		System.out.println("In Before");

	}

	// test annotation has been created
	@Test
	public void test() throws IOException, SQLException,
			FlatRegServiceException {
		assertNotNull(dao.registerFlat(bean));

		bean.setOwnerIdNo(1);
		bean.setFlatType(1);
		bean.setFlatArea(650);
		bean.setRentAmount(7000);
		bean.setDepositAmount(25000);

	}

	// after class annotation has been created
	@AfterClass
	public static void deinitializes() {
		System.out.println("In After Class");

	}

	// after annotation has been created
	@After
	public void deini() {

		System.out.println("In After");
	}
}
