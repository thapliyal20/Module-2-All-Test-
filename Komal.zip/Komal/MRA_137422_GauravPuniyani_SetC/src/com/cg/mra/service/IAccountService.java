package com.cg.mra.service;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Account Service Interface
	 */

	
//=================================================================================================================


import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;

public interface IAccountService {

	public Account getAccountDetails(String accountId) throws AccountException;
	
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException;
}
