package com.capgemini.bank.service;

import com.capgemini.bank.Exception.BankException;
import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService
{
	int addDemandDraftDetails(DemandDraft demandDraft) throws BankException;
	DemandDraft getDemandDraftDetails(int transactionId) throws BankException;

}
